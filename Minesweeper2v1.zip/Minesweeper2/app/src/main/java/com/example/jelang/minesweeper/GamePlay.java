package com.example.jelang.minesweeper;

import android.view.View;

/**
 * Created by Josh on 4/19/2016.
 */
public class GamePlay {

    private View v;

    private int row;

    private int col;

    private GenerateMaze maze;

    public GamePlay(View view, GenerateMaze m, int rows, int cols){
        v = view;
        maze = m;
        row  = v.getId() / cols;
        col = v.getId() % cols;
    }

    public void revealTile(){
        switch (maze.getSpace(row, col)){
            case "0":
                v.setBackgroundResource(R.drawable.hidden_space_pressed);
                break;
            case "1":
                v.setBackgroundResource(R.drawable.one);
                break;
            case "2":
                v.setBackgroundResource(R.drawable.two);
                break;
            case "3":
                v.setBackgroundResource(R.drawable.three);
                break;
            default:
                v.setBackgroundResource(R.drawable.hidden_space_pressed);
        }
    }
}
