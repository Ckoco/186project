package com.example.jelang.minesweeper;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;

/**
 * Created by Josh on 3/1/2016.
 */
public class DisplayBoard extends AppCompatActivity {

    private TableLayout mineField;

    private Button[][] buttonsArray;

    private Button button;

    private int rows;

    private int cols;

    private int mines;

    private Bundle dims;

    private GenerateMaze maze;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board_layout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mineField = (TableLayout) findViewById(R.id.board);
        Intent intent = getIntent();
        dims = intent.getExtras();
        rows = dims.getInt("height");
        cols = dims.getInt("width");
        mines = dims.getInt("mines");

        buttonsArray = new Button[rows][cols];

        maze = new GenerateMaze(cols, rows, mines);

        displayMines();
    }

    private void displayMines(){
        for(int i = 0; i < rows; i++){
            TableRow currentRow = new TableRow(this);
            int width = getResources().getDisplayMetrics().widthPixels;
            for(int j = 0; j < cols; j++){
                button = new Button(this);
                button.setId(i * cols + j);
                button.setBackgroundResource(R.drawable.button_toggle);
                button.setLayoutParams(new TableRow.LayoutParams(j));
                button.setLayoutParams(new TableRow.LayoutParams(width / cols, width / cols));
                button.setText(maze.getSpace(i, j));
                if(button.isClickable()){
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            GamePlay game = new GamePlay(v, maze, rows, cols);
                            game.revealTile();


//                            int row  = v.getId() / cols;
//                            int col = v.getId() % cols;
//                            switch (maze.getSpace(row, col)){
//                                case "0":
//                                    v.setBackgroundResource(R.drawable.hidden_space_pressed);
//                                    break;
//                                case "1":
//                                    v.setBackgroundResource(R.drawable.one);
//                                    break;
//                                case "2":
//                                    v.setBackgroundResource(R.drawable.two);
//                                    break;
//                                case "3":
//                                    v.setBackgroundResource(R.drawable.three);
//                                    break;
//                                default:
//                                    v.setBackgroundResource(R.drawable.hidden_space_pressed);
//                            }
                        }
                    });
                }
                currentRow.addView(button);
            }
            mineField.addView(currentRow);
        }
    }

    public void play(View v){

    }
}
