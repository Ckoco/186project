package com.example.jelang.minesweeper;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

public class MyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void start9x9(View view){
        Intent intent = new Intent(this, DisplayBoard.class);
        Bundle dimensions = new Bundle();
        dimensions.putInt("height", 9);
        dimensions.putInt("width", 9);
        dimensions.putInt("mines", 10);
        intent.putExtras(dimensions);
        startActivity(intent);
    }

    public void start16x16(View view){
        Intent intent = new Intent(this, DisplayBoard.class);
        Bundle dimensions = new Bundle();
        dimensions.putInt("height", 16);
        dimensions.putInt("width", 16);
        dimensions.putInt("mines", 40);
        intent.putExtras(dimensions);
        startActivity(intent);
    }

    public void start20x20(View view){
        Intent intent = new Intent(this, DisplayBoard.class);
        Bundle dimensions = new Bundle();
        dimensions.putInt("height", 20);
        dimensions.putInt("width", 20);
        dimensions.putInt("mines", 64);
        intent.putExtras(dimensions);
        startActivity(intent);
    }
}
